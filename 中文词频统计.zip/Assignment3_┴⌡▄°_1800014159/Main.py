# -*- coding: utf-8 -*-
# @Time : 2022/3/7 3:02
# @Author : gemma_leo
# @File : Main.py

import Frame

if __name__ == '__main__':
    a = Frame.frame()
    a.mainloop()
